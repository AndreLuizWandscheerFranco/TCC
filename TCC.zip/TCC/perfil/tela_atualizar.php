<?php 

session_start();

$conn = new mysqli("localhost", "root", "root", "Banco_de_dados");
if ($conn->connect_error) die("Erro: " . $conn->connect_error);


$id_usuario = $_SESSION['usuario']['id_usuarios'];

$id_usuario = $_POST["id_usuarios"];

$stmt = $conn->prepare("UPDATE usuarios SET nome, nome_de_usuario, cpf, telefone, cep, rua, bairro, complemento, numero, estado, email, senha, tipo
  WHERE id_usuarios=?
");

$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();
$nome = $usuario["nome"];
$Nome_de_usuario = $usuario["Nome_de_usuario"];
$cpf = $usuario["cpf"];
$telefone = $usuario["telefone"];
$cep = $usuario["cep"];
$rua = $usuario["rua"];
$bairro = $usuario["bairro"];
$complemento = $usuario["complemento"];
$numero = $usuario["numero"];
$estado = $usuario["estado"];
$email = $usuario["email"];
$senha = $usuario["senha"];
$tipo = $usuario["tipo"];

//print_r($usuario);
//die()

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar Dados</title>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar Dados</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            padding: 20px;
            display: flex;
            justify-content: center;
        }
        .form-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        input[type="text"], input[type="number"], input[type="email"], input[type="password"], input[type="file"] {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            outline: none;
        }
        input[type="text"]:focus, input[type="number"]:focus, input[type="email"]:focus, input[type="password"]:focus {
            border-color: #007BFF;
        }
        .botoes-form {
            display: flex;
            justify-content: space-between;
            gap: 10px;
        }
        .btn-cancelar, .btn-enviar {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
        }
        .btn-cancelar {
            background-color: #f44336;
            color: #fff;
        }
        .btn-enviar {
            background-color: #007BFF;
            color: #fff;
        }
        .btn-cancelar:hover {
            background-color: #d32f2f;
        }
        .btn-enviar:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Atualizar Dados</h2>
        <form action="selecionar_produto.html" method="POST" enctype="multipart/form-data">
            <input type="text" name="nome" placeholder="Nome" value= "<?php echo($nome);?>" required>
            <input type="text" name="nome_usuario" placeholder="Nome de usuário" value="<?php echo($Nome_de_usuario); ?>" required>
            <input type="text" name="cpf" placeholder="CPF" value="<?php echo ($cpf); ?>" required>
            <input type="text" name="telefone" placeholder="Telefone" value="<?php echo ($telefone); ?>" required>
            <input type="text" name="cep" placeholder="CEP" value="<?php echo ($cep); ?>" required>
            <input type="text" name="rua" placeholder="Rua" value="<?php echo ($rua); ?>" required>
            <input type="text" name="bairro" placeholder="Bairro" value="<?php echo ($bairro0); ?>" required>
            <input type="text" name="complemento" placeholder="Complemento" value="<?php echo ($complemento); ?>" required>
            <input type="number" name="numero" placeholder="Número" value="<?php echo ($numero); ?>" required>
            <input type="text" name="estado" placeholder="Estado" value="<?php echo ($estado); ?>" required>
            <input type="email" name="email" placeholder="Email" value="<?php echo ($email); ?>" required>
            <input type="password" name="senha" placeholder="Senha" value="<?php echo ($senha); ?>" required>
            <input type="text" name="tipo" placeholder="Tipo" value="<?php echo ($tipo); ?>" required>

            <div class="botoes-form">
                <button type="button" class="btn-cancelar" onclick="window.location.href='./index.html'">Cancelar</button>
                <button type="submit" class="btn-enviar">Atualizar</button>
            </div>
        </form>
    </div>
</body>
</html>

</body>
</html>
